$(document).ready(function() {
	console.log("landing.js");
	$(".active").removeClass("active");
	$("#homeHeader").addClass("active");
});
